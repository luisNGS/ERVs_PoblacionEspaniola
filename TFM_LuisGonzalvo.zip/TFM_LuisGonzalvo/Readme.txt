Este carpeta contiene las figuras y los script utilizados para el TFM 'Herramientas bioinformáticas para el estudio de retrovirus endógenos en población española'.

La carpeta Figuras contiene todas las figuras más importantes que se describen en el trabajo. Además se incluyen gráficas y ficheros que no se han añadido a la memoria (Figura9 y Figura19_20). 

La carpeta scriptsFiguras contiene aquellos script que se han utilizado para generar las figuras, el número del script se relaciona con el número de la figura.

La carpeta scriptsProyecto contiene los scripts que se han utilizado durante todo el proceso del trabajo. Para facilitar el entendimiento se han agrupado los scripts en carpetas con nombres que referencian la etapa del flujo de análisis que se describe en el trabajo (Figura 4).

Debido a la gran cantidad de ficheros y a su peso no se han añadido a esta carpeta. Debido a esto, muchos de los scripts dan error debido a la falta de ficheros de entrada, pero son plenamente funcionales.
