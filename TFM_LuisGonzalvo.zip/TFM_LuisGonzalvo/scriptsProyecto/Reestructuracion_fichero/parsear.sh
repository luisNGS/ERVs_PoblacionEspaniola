#!/bin/bash

set -x

mapping_file=$1
vcf_list_file=$2
root_output_dir=$3
job_logs_dir=$4
#
## Cargamos el modulo de python
module load python
module load pycellbase
#
# Obtener la muestra actual y crear una hoja de muestra
current_sample_info=$(sed -n $(( SLURM_ARRAY_TASK_ID ))p $vcf_list_file) # Obtiene fila SLURM_ARRAY_TASK_ID del fichero BAM_list_file
current_sample_id=$(echo $current_sample_info | cut -f 1 -d',') # Nos quedamos con la primera columna, es decir, el ID de la muestra
current_sample=$(echo $current_sample_info | cut -f 2 -d',') # Nos quedamos con la segunda columna, es decir, el la ruta completa de la muestra
#
# add sample ID <-> slurm log ID to mapping file
printf "\n$current_sample_id\t${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}" >> $mapping_file # De cara a revisiones, guardamos en mapping_file el ID de la muestra junto con su job ID correspondiente
#
## Codigo para ERVcaller
# Declaramos las rutas
#
----------------------------------------------------------------------
## Aqui me he quedado
output_dir=$root_output_dir # Directorio de salida de ERV caller (cada muestra va a un directorio propio)
#
#
arrIN=(${current_sample//'/'/ })
num=${#arrIN[@]}
let c=$num-1
# Obtenemos la ruta de la muestra
longNom=${#arrIN[$c]}
longLine=${#current_sample}
let longFinal=$longLIne-$longNom
rutaCarpeta=${current_sample:0:${longFinal}}
#
fichero=${arrIN[$c]}
arrDot=(${current_sample//'.'/ })
# Obtenemos el formato
formato=.${arrDot[-1]}
long_formato=${#formato}
let len=${#fichero}-$long_formato
# Obtenemos el nombre de la muestra
nomFich=${fichero:0:${len}}
fich_out=$output_dir'/cat_'$nomFich'.gtf'
#
if [ ! -d $output_dir ];
then
	mkdir $output_dir
fi
#
python /home/lgonzalvo/TFM/csvs_examples/github/ERVanalysis/CatalogoMuestra.py $current_sample $fich_out /home/lgonzalvo/TFM/csvs_examples/github/ERVanalysis/fich_long.txt
#echo $nomFich
#echo $fich_out
#echo $current_sample
