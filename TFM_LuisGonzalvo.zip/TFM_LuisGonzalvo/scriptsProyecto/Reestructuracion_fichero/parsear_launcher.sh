#!/bin/bash -l
#
vcf_list_file=$1 # Fichero csv donde por cada fila tenemos <path_to_vcf_file>
root_output_dir="/home/lgonzalvo/TFM/csvs_gtf" # Carpeta de salida
#
num_samples=$(wc -l $vcf_list_file| cut -f1 -d " ")
#
memory=50GB
cpus=1
num_concurrent_jobs=10
jobName='Parsear'

job_logs_dir=$root_output_dir'/job_logs/'
mkdir -p $job_logs_dir

mapping_file=$job_logs_dir'parsear_slurm_id_mapping.csv'
#
printf "SAMPLE ID\tSLURM_LOG_ID (ARRAY.JOB.ID_ARRAY.TASK.ID)" > $mapping_file
printf [1-$num_samples]%num_concurrent_jobs >> $root_output_dir'/job_logs/fich_prueba.csv'
#
# Array job: gestiona todos los jobs, de forma que solo pueden ejecutarse concurrentemente num_concurrent_jobs sobre el total de jobs (num_samples)
#
sbatch --array [1-$num_samples]%$num_concurrent_jobs --job-name=$jobName --mem=$memory --cpus-per-task=$cpus --output=$job_logs_dir/%A_%a'.out' --error=$job_logs_dir/%A_%a'.err' /home/lgonzalvo/TFM/csvs_examples/github/ERVanalysis/parsear.sh $mapping_file $vcf_list_file $root_output_dir $job_logs_dir

