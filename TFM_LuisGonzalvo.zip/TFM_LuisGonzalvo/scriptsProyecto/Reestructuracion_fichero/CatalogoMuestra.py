#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 18 16:34:21 2021

@author: luis
"""

from pycellbase.cbconfig import ConfigClient
from pycellbase.cbclient import CellBaseClient
import sys

def obtenerListaRetrovirus(ficheros):
    
    listaRetrovirus = []
    
    print(type(ficheros))
    if type(ficheros) == list:
        
        
        for f in ficheros:
            fichOpen = open(f, "r")
            
            for linea in fichOpen:
                if linea[0] != "#":
                    campos = linea.split("\t")
                    
                    if campos[4] not in listaRetrovirus:
                        listaRetrovirus.append(campos[4])
                        
            fichOpen.close()
            
    else:
        fichOpen = open(ficheros, "r")
            
        for linea in fichOpen:
            if linea[0] != "#":
                campos = linea.split("\t")
                    
                if campos[4] not in listaRetrovirus:
                    listaRetrovirus.append(campos[4])
                        
        fichOpen.close()
        
            
    return listaRetrovirus 

def obtenerLongRetrovirus(listaRetrovirus, fichLong):
    dic = {}
    listaRetrovirus_mod = []
    for l in listaRetrovirus:
        retrovirus = l[9:-1]
        listaRetrovirus_mod.append(retrovirus)
        
    
    fich = open(fichLong, "r")
    
    for linea in fich:
        campos = linea.split("\t")
        
        if campos[0] in listaRetrovirus_mod:
            
            dic[campos[0]] = campos[1]
            
    
    
    return dic



def obtenerDatos(nom_fich, c):
    

    fich = open(nom_fich, "r")
  
    contador = 0
    listaFichero = []
    dicDatos = {}
        
            
    for l in fich:
        
        if l[0] != "#":

            campos = l.split("\t")
            chrom = campos[0]
            inicio = campos[1]
            retroVirus = campos[4]
            ident = campos[4]
            ident = "id_" + ident[9:-1]
            
            inf = campos[7]
            
            camposInf = inf.split(";")
            camposInf = camposInf[1].split(",")
            retrIn = camposInf[1]
            retrFin = camposInf[2] 
            retrLen = camposInf[3]
            strand = camposInf[4]
            
           
            
            if c == chrom:
                
                if retrLen == "NULL":
                    fin = "NULL"
                else:
                    fin = int(inicio) + int(retrLen)
                  
                
                write = chrom + "\t" + ident + "\t" + "Retrovirus" + "\t" + str(inicio) + "\t" + str(fin) + "\t" + "." + "\t" + str(strand) + "\t" + "." + "\t" # + "ID%3D" + ident[3:] + ";" + "\n"



                # Filtrar para cuando no se sabe el inicio y el final
                if retrLen == "NULL":
                    if inicio != "NULL":
                        fin = inicio
                    if fin != "NULL":
                        inicio = fin
                   

                listaGenes = obtenerDatosGenes(chrom, inicio, fin)

                
                if len(listaGenes) >= 1:
                
                    for gen in listaGenes:
                        write +=  "genID=" + gen + ";"
                
                else:
                    
                    write += "-"
                
                write += "\t" 
                
                ## Escribo las posiciones del retrovirus: 
                    
                write += "INFOR=" + ident + "," + retrIn + "," + retrFin + "," + retrLen

                write += "\n"
                
                print(write)
                
                dicDatos[int(inicio)] = write


    fich.close()
    
    return dicDatos


def obtenerDatosGenes(cromosoma, inicio, final):

  
    import requests
    import json
    lista = []

    request = requests.get( 'http://cellbase.clinbioinfosspa.es/cellbase-4.6.3/webservices/rest/v4-dev2/hsapiens/genomic/region/'+ str(cromosoma) + ':' + str(inicio) + '-' + str(final) +'/gene')
    data = json.loads(request.text)
    
    
    x = data['response'][0]['result']

    n_genes = len(x)

    for i in range(n_genes):
        gene_name = str(data['response'][0]['result'][i]['name'])
        lista.append(gene_name)

    
    return lista
    
    
if __name__ == '__main__':
    
    fich = sys.argv[1]
    nom_fich_out = sys.argv[2]
    fich_long = sys.argv[3]


    cromosomas = ["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","X","Y"]
    

    listaRetrovirus = obtenerListaRetrovirus(fich)
    
    dicLong = obtenerLongRetrovirus(listaRetrovirus, fich_long)
    ###
    
    contChrTotal = 0
    contNullTotal = 0
    contAgrupacionesTotal = 0

    
    fich_out = open(nom_fich_out, "w")
    fich_out.close()
    
    fich_out = open(nom_fich_out, "a")

    write = "#Chromosoma\tId\tType\tSeq_in\tSeq_end\tQuality\tStrand\tOther\tIDGen_CellBase\tposRetrovirus\n"
    fich_out.write(write)

    for c in cromosomas:

        dicDatos = obtenerDatos(fich, c)
        data_sort = sorted(dicDatos)
        
        for c in data_sort:
            write = dicDatos[c]
            
            fich_out.write(write)
        

            
    fich_out.close()

