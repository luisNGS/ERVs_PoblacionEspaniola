#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Aug  8 12:35:01 2021

@author: luis
"""


def obtenerFicheros(muestrasNoRelacionadas):
    
    listaMuestras = []
    idMuestras = []
    
    fich = open(muestrasNoRelacionadas, "r")
    
    for linea in fich:
        linea = linea.strip("\n")
        cad = "cat_" + linea + ".sorted.dedup.gtf"
        listaMuestras.append(cad)
        idMuestras.append(linea)
        
    fich.close()
        
    return listaMuestras, idMuestras



def obtenerEnsembl(nom_fich, dicEnsembl):
        
    dicEnsembl_final = {}
    fich = open(nom_fich, "r")
    
    cont = 0
    
    for linea in fich:
        cont += 1

        if linea[0] != "#":
 
            campos = linea.split("\t")

            if len(campos) > 8:
                anot = campos[8].split(";")
            
                # print(anot[0], anot[5])
                
                ensem = anot[0]
                ensem = ensem[9:-1]
                
                geneId = anot[5]
                geneId = geneId[12:-1]
  
                # print(ensem, geneId)
                if geneId in dicEnsembl:
                    dicEnsembl[geneId] = ensem
                
        
    fich.close()
                
    return dicEnsembl
        
def obtenerDic(nomFic_genes):
    
    fich = open(nomFic_genes, "r")
    dicEnsembl = {}
    dicGen = {}
    
    for linea in fich:
        linea = linea.strip("\n")

        campos = linea.split("\t")
        
        dicEnsembl[campos[0]] = ""
        dicGen[campos[0]] = campos[1]
        
    
    fich.close()
    
    return dicEnsembl, dicGen


def listaGenes(fich_listaGenes):
    
    fich = open(fich_listaGenes, "r")
    
    listaGenesHeredados = []
    
    for linea in fich:
        if linea[0] != "#":
            linea = linea.strip("\n")
            
            gen = linea[6:]
            
            listaGenesHeredados.append(gen)
            
            
        
    fich.close()

    return listaGenesHeredados
        

def listaHPO(fich_hpo, fich_hpo_description):
    
    fich = open(fich_hpo_description, "r")
    dicHPO_desc = {}
    dicHPO_list_genes = {}
    dicHPO_genes = {}
    listaGenes_hpo = []
    
    for linea in fich:
        linea = linea.strip("\n")
        campos = linea.split("\t")
        
        dicHPO_desc[campos[0]] = campos[1]
        dicHPO_list_genes[campos[0]] = []
        
        
        
    
    fich.close()
    
    
    fich = open(fich_hpo, "r")
    
    for linea in fich:

        linea = linea.strip("\n")
        linea = linea.replace('"', '')
        campos = linea.split(",")

        if campos[0] in dicHPO_list_genes:
            
            dicHPO_list_genes[campos[0]].append(campos[2])
            listaGenes_hpo.append(campos[2])
            cad = campos[2] + "\t" + campos[1] + "\t" + campos[0] + "\t" + dicHPO_desc[campos[0]] + "\t" + campos[3]
            dicHPO_genes[campos[2]] = cad

    fich.close()
    
    contador = 0
    
    # for key in dicHPO_genes:
    #     print(key, dicHPO_genes[key])
    
    
    # for key in dicHPO_list_genes:
    #     print(key, dicHPO_list_genes[key])
    #     contador += len(dicHPO_list_genes[key])
        
    # print(contador)
    
    return dicHPO_desc, dicHPO_genes, dicHPO_list_genes, listaGenes_hpo


def main():
    
    
    carpeta = "./muestrasNoRelacionadas/MuestrasNoRelacionadas_completa"
    fich_listaGenesHeredados = "listaGenes_alelosHeredados.txt"
    fich_hpo = "./gpProfiler/gProfiler_hpo_heredados.csv"
    fich_hpo_description = "./gpProfiler/gProfiler_hpo_heredados_description.txt"
    listaGenesHeredados = listaGenes(fich_listaGenesHeredados)
    
    listaMuestras, idMuestas = obtenerFicheros(carpeta)
    # listaMuestras = ["cat_fich1.sorted.dedup.gtf", "cat_fich2.sorted.dedup.gtf"]
    
    dicHPO_desc, dicHPO_genes, dicHPO_list_genes, listaGenes_hpo = listaHPO(fich_hpo, fich_hpo_description)
    
    dicGenes =  {}
    
        
    carpetaHPO = "./HPO_muestras/"
    
    for muestra in listaMuestras:
        fich = open(muestra, "r")
        dicGenesMuestra = {}
        
        
        nomFich_out = carpetaHPO + muestra
        print(nomFich_out)
        fich_out = open(nomFich_out, "w")
        fich_out.close()
        
        fich_out = open(nomFich_out, "a")
        
        cad = "# Chromosoma\tPosition\tRetrovirus\tGeneSymbol\tENSEMBL\tHPO\tHPO_description\tGene_description\n"
        
        for linea in fich:
            if linea[0] != "#":
                linea = linea.strip("\n")

                campos = linea.split("\t")
                retr = campos[1]
                retr = retr[3:]
                
                chrom = campos[0]
                pos = campos[3]

                genes = campos[8]
                
                if genes != "-":
                    genes = genes[:-1]
                    
                    genes = genes.split(";")
                    
                    for gen in genes:

                        gen = gen[6:]
                        
                        if gen in listaGenes_hpo:
                            print(gen, dicHPO_genes[gen], retr)
                            
                            cad += chrom + "\t" + pos + "\t" + retr + "\t" + dicHPO_genes[gen] + "\n"
                            
        
        cad = cad[:-1]
        fich_out.write(cad)
        
        fich_out.close()
        fich.close()
        


        

    
if __name__ == '__main__':
    
    main()
    
