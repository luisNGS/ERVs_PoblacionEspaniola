#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 14 18:06:06 2021

@author: luis
"""

def obtenerMuestras_Loci(fichMatrix):
    
    fich = open(fichMatrix, "r")
    listaMuestras = []
    dicLoci = {}
    listaRetrovirus = []
    for linea in fich:
        linea = linea.strip("\n")
        if linea[0] == "#":
            listaMuestras = linea.split("\t")
            
            ## Quita el primer caracter # y el ultimo ""
            listaMuestras.pop(0)
            listaMuestras.pop()
            
            
        else:
            
            campos = linea.split("\t")
            locus = campos[0]
            dicLoci[locus] = ""
            camposLocus = locus.split("_")
            retrovirus = camposLocus[2]
            
            if retrovirus not in listaRetrovirus:
                listaRetrovirus.append(retrovirus)
            
            
            
            

    return listaMuestras, dicLoci, listaRetrovirus

def main():

    fich_inf = "informacionLociRetrovirus.txt"
    fich_matrix = "matrixAlelosFamilias.txt"
    
    ficheroLoci = "./lociFamilias/1_lociFamilias.txt"
    
    fich = open(ficheroLoci, "r")
    
    for linea in fich:
        alelos = linea.split("\t")
        
    fich.close()
        
    print(len(alelos))
    print(alelos)
    fich = open(fich_inf, "r")
    listaGenes = []
    
    for linea in fich:
        
        print(linea)
        
        campos = linea.split("\t")
        gen = campos[2]
        gen = gen[:-2]
        genes = gen.split(";")
        
        
        for g in genes:
            g = g[6:]
            if g != "" and g not in listaGenes:
    
                listaGenes.append(g)
            
            
        
    print(listaGenes)
    print(len(listaGenes))
        
    fich.close()
    

if __name__ == '__main__':
    
    main()