#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Aug 28 17:28:39 2021

@author: luis
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jul 19 15:53:29 2021

@author: luis
"""

import os
import matplotlib.pyplot as plt
import numpy as np
import math
from math import pi
import pandas as pd
from bokeh.io import show
from bokeh.models import BasicTicker, ColorBar, LinearColorMapper, PrintfTickFormatter
from bokeh.plotting import figure, output_file
from bokeh.sampledata.unemployment1948 import data

def obtenerFicheros(muestrasNoRelacionadas):
    
    listaMuestras = []
    idMuestras = []
    
    fich = open(muestrasNoRelacionadas, "r")
    
    for linea in fich:
        linea = linea.strip("\n")
        cad = linea
        listaMuestras.append(cad)
        idMuestras.append(linea)
        
    fich.close()
        
    return listaMuestras, idMuestras

def main():
    
    
    carpeta = "/home/luis/Bioinformatica/TFM/Presentacion/datos_csvs/muestrasNoRelacionadas/MuestrasNoRelacionadas_completa"
    fichMatrix = "/home/luis/Bioinformatica/TFM/Presentacion/datos_csvs/matrizAlelos.txt"
    fich_long = "/home/luis/Bioinformatica/TFM/Presentacion/datos_csvs/fich_long.txt"
    

    nomFich_matrix_out = "./matrix_MuestraRepresentativa.txt"
    
    listaMuestras, idMuestras = obtenerFicheros(carpeta)

    fich = open(fichMatrix, "r")
    
    listaGenes = []
    dicAlelos = {}
    contAlelos = 0
    for linea in fich:
        linea = linea.strip("\n")
        if linea[0] == "#":
            
            muestras = linea.split("\t")
            muestras = muestras[1:-1]

            
        else:
            contAlelos += 1
            campos = linea.split("\t")
            alelo = campos[0]
            campos = campos[1:-1]
            
            dicAlelos[alelo] = []
     

            for i in range(len(campos)):
                
                dicAlelos[alelo].append(int(campos[i]))


    nMuestras = len(muestras)
    
    print(nMuestras)
    
    listaAlelos = []
    retr = []
    for key in dicAlelos:

        valorAlelo = sum(dicAlelos[key])
        
        if valorAlelo >= 362:
            listaAlelos.append(key)
            
            campos = key.split("_")
            
            if campos[2] not in retr:
                retr.append(campos[2])

    
    print(len(listaAlelos))
    print(len(retr), retr)
    fich.close()
    
    
    
    fich_out = open(nomFich_matrix_out, "w")
    fich_out.close()
    
    fich_out = open(nomFich_matrix_out, "a")
    
    fich = open(fichMatrix, "r")
    
    listaGenes = []
    dicAlelos = {}
    contAlelos = 0
    camposValidos = []
    for linea in fich:
        linea = linea.strip("\n")
        if linea[0] == "#":
            
            muestrasFichero = linea.split("\t")
            muestrasFichero = muestrasFichero[1:-1]
            
            cad = "#\t"
            
            for i in range(len(muestrasFichero)):
 
                # mFich = .strip("\t")
                if muestrasFichero[i] in listaMuestras:
                    print("aquiii")
                    camposValidos.append(i)
                    cad += muestrasFichero[i] + "\t"
                
            
            cad += "\n"
            
            
        else:
            
            
            
            contAlelos += 1
            campos = linea.split("\t")
            alelo = campos[0]
            campos = campos[1:-1]
            
            if alelo in listaAlelos:
                
            
                cad += alelo + "\t"
                
                for i in camposValidos:
                    
                    cad += campos[i] + "\t"
                    
                cad += "\n"
                
            
    fich_out.write(cad)
    fich_out.close()
            
    fich.close()
            
            


    
    
    
if __name__ == '__main__':

    main()

    
    
    
    
    
    