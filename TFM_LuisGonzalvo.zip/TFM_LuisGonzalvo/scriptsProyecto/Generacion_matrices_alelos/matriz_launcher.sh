#!/bin/bash

set -x

mapping_file=$1
lista_mod=$2
root_output_dir=$3
job_logs_dir=$4
#
## Cargamos el modulo de python
module load python

output_dir=$root_output_dir # Directorio de salida de ERV caller (cada muestra va a un directorio propio)
#
#
ficheros=$(ls *.gtf)
ficheros_mod=${ficheros// /:}
#
python /home/lgonzalvo/TFM/csvs_gtf/matrizLoci.py $lista_mod $ficheros_mod /home/lgonzalvo/TFM/csvs_examples/github/ERVanalysis/fich_long.txt


