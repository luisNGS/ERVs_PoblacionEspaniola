#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jun 6 15:16:10 2021

@author: luis
"""
import os
from datetime import datetime




def obtenerListaRetrovirus(ficheros):
    
    listaRetrovirus = []
    
    print(type(ficheros))
    if type(ficheros) == list:
        
        
        for f in ficheros:
            fichOpen = open(f, "r")
            #print(f) 
            for linea in fichOpen:
                if linea[0] != "#":
                    campos = linea.split("\t")
                    #print(campos)
                    retroVirus = campos[1]
                    retroVirus = retroVirus[3:]
                    
                    
                    if retroVirus not in listaRetrovirus:
                        
                        if retroVirus == "NULL":
                            print(linea)
                        
                        listaRetrovirus.append(retroVirus)
                        
            fichOpen.close()
            
    else:
        fichOpen = open(ficheros, "r")
            
        for linea in fichOpen:
            if linea[0] != "#":
                campos = linea.split("\t")
                retroVirus = campos[1]
                retroVirus = retroVirus[3:]
                    
                if retroVirus not in listaRetrovirus:
                    listaRetrovirus.append(retroVirus)
                        
        fichOpen.close()
        
            
    return listaRetrovirus # listaLongitud   

def obtenerLongRetrovirus(listaRetrovirus, fichLong):
    dic = {}

    
    fich = open(fichLong, "r")
    
    for linea in fich:
        campos = linea.split("\t")
        
        if campos[0] in listaRetrovirus:
            dic[campos[0]] = campos[1].strip("\n")
            
    return dic




def main():
    

    listaLoci = []
    cromosomas = ["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","X","Y"]
    fich_long = "fich_long.txt"
    
    ## Importante elegir el directorio donde estás las muestras que quieres comparar
    ## Permite obtener con el mismo script la matriz de todos los alelos y de la famila. También permite filtrar por número de muestras (Matriz alelos muestra representativa)
    directorio = "./" 
    
    now = datetime.now()


    listaFicheros_directorio = os.listdir(directorio)
    listaFicheros = []
    i = 0
    write = ""
    
    for fichero in listaFicheros_directorio:
        
        camposFich = fichero.split(".")
        
        if camposFich[-1] == "gtf":
            i += 1
            print(fichero)
            listaFicheros.append(fichero)
            
    print("cargados ", i, "ficheros")
    
    listaRetrovirus = obtenerListaRetrovirus(listaFicheros)
    dicLong = obtenerLongRetrovirus(listaRetrovirus, fich_long)
    
    contadorRetrovirus = len(listaRetrovirus)

    contador = 0
    contadorRep = 0
    
    
    for c in cromosomas:

        dicLoci = {}
        for fichero in listaFicheros:
            print(fichero)
            fich = open(fichero, "r")
            
            listaAux = []
            
            
            
            
            for linea in fich:
                if linea[0] != "#":
                    campos = linea.split("\t")
                    chrom = campos[0]
                    retroVirus = campos[1]
                    retroVirus = retroVirus[3:]
                    

                    posIn = int(campos[3])
                    
                    #if chrom == "1":
                    if c == chrom:
                        
                        
                        
                        longRetrovirus = int(dicLong[retroVirus])
                        
                        locusIn = posIn - longRetrovirus
                        locusFin = posIn + longRetrovirus
                        
                        var = False
                        
                        for key in dicLoci:
                            # key es la longitud
                            
                            if key > locusIn and key < locusFin:
                                aux = dicLoci[key]
                                aux = aux.split("_")
                                if retroVirus in aux:
                                    
                                    var = True
                            
                        
                        if var == False:
                            contador += 1
                            if posIn not in dicLoci:
                                dicLoci[posIn] = retroVirus + "_"
                            else:
                                dicLoci[posIn] += retroVirus + "_"
                            

            fich.close()

        
        for key in dicLoci:
            campos = dicLoci[key].split("_")
            if len(campos) > 2:
                contadorRep += 1
            
            for i in campos:
                if i != "":
                    
                    write += c + "_" + str(key) + "_" + i + "\n"
                    #fich_out.write(write)

        listaLoci = []
        

    print(contadorRep)
    print(contador)
    
    
    nomFich_out = "loci.txt"
    
    
    fich_out = open(nomFich_out, "w")
    fich_out.close()
    fich_out = open(nomFich_out, "a")
    
    cad = "## Date: " + str(now.day) + "/" + str(now.month) + "/" + str(now.year) + "\n"
    
    cad += "### Loci Total encontrados: " + str(contador) + "\n"
    cad += "### Loci repetidos por distintos retrovirus: " + str(contadorRep) +"\n"
    cad += "## Retrovirus encontrados: " + str(contadorRetrovirus) + "\n"
    
    for r in listaRetrovirus:
        cad += "## " + r + "\n"
    
    
    cad += "# chrom_pos_retrovirus\n"
    fich_out.write(cad)
    
    fich_out.write(write)

    fich_out.close()

            
if __name__ == '__main__':
    main()
                
        
    


