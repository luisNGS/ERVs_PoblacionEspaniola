#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jun 6 11:33:10 2021

@author: luis
"""
import os
from datetime import datetime
import sys


def obtenerListaRetrovirus(ficheros):
    
    listaRetrovirus = []
    
    print(type(ficheros))
    if type(ficheros) == list:
        
        
        for f in ficheros:
            fichOpen = open(f, "r")
            
            for linea in fichOpen:
                if linea[0] != "#":
                    campos = linea.split("\t")
                    retroVirus = campos[1]
                    retroVirus = retroVirus[3:]
                    
                    
                    if retroVirus not in listaRetrovirus:
                        
                        if retroVirus == "NULL":
                            print(linea)
                        
                        listaRetrovirus.append(retroVirus)
                        
            fichOpen.close()
            
    else:
        fichOpen = open(ficheros, "r")
            
        for linea in fichOpen:
            if linea[0] != "#":
                campos = linea.split("\t")
                retroVirus = campos[1]
                retroVirus = retroVirus[3:]
                    
                if retroVirus not in listaRetrovirus:
                    listaRetrovirus.append(retroVirus)
                        
        fichOpen.close()
        
            
    return listaRetrovirus # listaLongitud   

def obtenerLongRetrovirus(listaRetrovirus, fichLong):
    dic = {}

    
    fich = open(fichLong, "r")
    
    for linea in fich:
        campos = linea.split("\t")
        
        if campos[0] in listaRetrovirus:
            dic[campos[0]] = campos[1].strip("\n")
            
    return dic


def obtenerListaLoci(fich_loci):
    
    listaLoci = []
    fich = open(fich_loci, "r")
    
    for linea in fich:
        if linea[0] != "#":
            linea = linea.strip("\n")
            
            listaLoci.append(linea)
        
    fich.close()
    return listaLoci




def main():
    
    fich_Loci = sys.argv[1]
    rutaFicheros = sys.argv[2]
    fich_long = sys.argv[3]
    
    listaFicheros = []

    parte = fich_Loci.split("/")
    parte = parte[-1].split("_")
    nomFich = "./" + parte[0] + "_matrixLoci.txt"
    
    fich_out = open(nomFich, "w")
    fich_out.close()
    
    fich_out = open(nomFich, "a")

    
    
    ficheros = os.listdir(rutaFicheros)
    
    write = "#\t"
    
    for f in ficheros:
        campos = f.split(".")
        if campos[-1] == "gtf":
            listaFicheros.append(f)
            
            z = campos[0].split("_")
            write += z[1] + "\t"
        campos = f.split(".")
        
    
    write += "\n"
    
    if parte[0] != "1":
        write = ""    
    
    fich_out.write(write)

    
    listaLoci = obtenerListaLoci(fich_Loci)
    listaRetrovirus = obtenerListaRetrovirus(listaFicheros)
    dicLong = obtenerLongRetrovirus(listaRetrovirus, fich_long)
    
    for locus in listaLoci:
        

        if locus[0] != "#":

            carpeta = "./loci/"

            i = 0
        
            campos = locus.split("_")
 
            c = campos[0]
            pos = campos[1]
            retrovirus = campos[2]

            cad = locus + "\t" 
            for fichero in listaFicheros:
        
                fich = open(fichero, "r")
                
                listaAux = []
                contadorLocus = 0
                
                for linea in fich:
                    if linea[0] != "#":
                        campos = linea.split("\t")
                        chrom = campos[0]
                        retroVirus = campos[1]
                        retroVirus = retroVirus[3:]
                        posIn = int(campos[3])

                        if c == chrom and retroVirus == retrovirus:
           
                            longRetrovirus = int(dicLong[retroVirus])
                            locusIn = posIn - longRetrovirus
                            locusFin = posIn + longRetrovirus
        
                            if int(pos) > locusIn and int(pos) < locusFin:
                                contadorLocus = 1
               
                cad += str(contadorLocus) + "\t"

        
                fich.close()
                
            cad += "\n"
              

            
            fich_out.write(cad)
        
    fich_out.close()

            
if __name__ == '__main__':
    main()
                
