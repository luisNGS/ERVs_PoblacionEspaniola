#!/bin/bash

set -x

mapping_file=$1
BAM_list_file=$2
root_output_dir=$3
job_logs_dir=$4
read_length=$5
#
# Cargamos los modulos
module load samtools/1.9
module load bwa
#
# Cargamos config_file
#source $config_file
#
# Obtener la muestra actual y crear una hoja de muestra
current_sample_info=$(sed -n $(( SLURM_ARRAY_TASK_ID ))p $BAM_list_file) # Obtiene fila SLURM_ARRAY_TASK_ID del fichero BAM_list_file
current_sample_id=$(echo $current_sample_info | cut -f 1 -d',') # Nos quedamos con la primera columna, es decir, el ID de la muestra
current_sample=$(echo $current_sample_info | cut -f 2 -d',') # Nos quedamos con la segunda columna, es decir, el la ruta completa de la muestra
#
# add sample ID <-> slurm log ID to mapping file
printf "\n$current_sample_id\t${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}" >> $mapping_file # De cara a revisiones, guardamos en mapping_file el ID de la muestra junto con su job ID correspondiente
#
## Codigo para ERVcaller
# Declaramos las rutas
#
# output_dir=$root_output_dir'/'$current_sample_id'/' # Directorio de salida de ERV caller (cada muestra va a un directorio propio)
output_dir=$root_output_dir'/' # Directorio de salida de ERV caller (cada muestra va a un directorio propio)
#
rutaPolimorphic="/home/lgonzalvo/TFM/polymorphicHERV-master"
bedFile=$rutaPolimorphic/bed_files/HERVK_hg37_sort.bed
rutaGenoma=$current_sample
extractedBAM=$rutaPolimorphic/extractedBAM
rutaDataSetSamples=$rutaPolimorphic/dataset_samples
rutaDsk="/home/lgonzalvo/TFM/dsk-2.1.0-Linux/bin/dsk"
rutaDskAscii="/home/lgonzalvo/TFM/dsk-2.1.0-Linux/bin/dsk2ascii"

arrIN=(${rutaGenoma//'/'/ })
num=${#arrIN[@]}
let c=$num-1
fichero=${arrIN[$c]}

fich_extract=${fichero:0:-4}.extracted.bam
fich_fa=${fichero:0:-4}.fa
fich_h5=${fichero:0:-4}.h5
fich_txt=${fichero:0:-4}.txt
fich_50fa=${fichero:0:-4}.50.fa
fich_dat=${fichero:0:-4}.dat
fich_label=${fichero:0:-4}.label
fich_mat=mat.$fich_dat

samtools view -b -L  $bedFile $rutaGenoma > $extractedBAM/$fich_extract


# Convertir BAM to Fasta

samtools view $extractedBAM/$fich_extract | awk '{print ">"$1"\n"$10}' > $extractedBAM/$fich_fa
#
# Herramienta desk para kamerizar la muestra
#
$rutaDsk -file $extractedBAM/$fich_fa -kmer-size 50 -abundance-min 0
$rutaDskAscii -file ./$fich_h5 -out $extractedBAM/$fich_txt
perl $rutaPolimorphic/tofasta.pl $extractedBAM/$fich_txt $extractedBAM/$fich_50fa
mv $extractedBAM/$fich_50fa $rutaDataSetSamples


rutaID=$rutaPolimorphic/Ids/id_${fichero:0:-4}
echo ${fichero:0:-4} > $rutaID
perl $rutaPolimorphic/findmatch.pl $rutaPolimorphic/unique.withrc.50.fa $rutaPolimorphic/dataset_samples/ $rutaPolimorphic/hashlabels_1000g_50/ 50 ${fichero:0:-4}
perl $rutaPolimorphic/labelcount.pl $rutaPolimorphic/hashlabels_1000g_50/$fich_dat $rutaPolimorphic/sortedSites $rutaPolimorphic/hashlabels_1000g_50/$fich_label
perl $rutaPolimorphic/concate_tomatrix.pl $rutaPolimorphic/T.50 $rutaID $rutaPolimorphic/hashlabels_1000g_50/ $output_dir/$fich_mat

rm $fich_h5 