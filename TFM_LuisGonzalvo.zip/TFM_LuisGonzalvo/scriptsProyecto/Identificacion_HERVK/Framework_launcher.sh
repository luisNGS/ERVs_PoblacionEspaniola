#!/bin/bash -l
#
BAM_list_file=$1 # Fichero csv donde por cada fila tenemos IDmuestra,<path_to_BAM_file>
config_file=$2 # Fichero cluster.config
#
#
source $config_file # Lee los parametros del fichero ERVcaller.config y los mete en las variables detalladas en ese fichero, utilizandose por tanto de forma directa
#
num_samples=$(wc -l $BAM_list_file| cut -f1 -d " ")
#
jobName='Framework'

job_logs_dir=$root_output_dir'/job_logs/'
mkdir -p $job_logs_dir

mapping_file=$job_logs_dir'framework_slurm_id_mapping.csv'
#
printf "SAMPLE ID\tSLURM_LOG_ID (ARRAY.JOB.ID_ARRAY.TASK.ID)" > $mapping_file
#
# Array job: gestiona todos los jobs, de forma que solo pueden ejecutarse concurrentemente num_concurrent_jobs sobre el total de jobs (num_samples)
#
sbatch --array [1-$num_samples]%$num_concurrent_jobs --job-name=$jobName --mem=$memory --cpus-per-task=$cpus --output=$job_logs_dir/%A_%a'.out' --error=$job_logs_dir/%A_%a'.err' /home/lgonzalvo/TFM/csvs_examples/github/ERVanalysis/Framework.sh $mapping_file $BAM_list_file $root_output_dir $job_logs_dir