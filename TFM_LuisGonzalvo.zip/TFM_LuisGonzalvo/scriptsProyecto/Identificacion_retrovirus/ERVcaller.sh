#!/bin/bash

set -x

mapping_file=$1
BAM_list_file=$2
root_output_dir=$3
job_logs_dir=$4
read_length=$5
#
# Cargamos los modulos
module load samtools/1.9
module load bwa
#
# Cargamos config_file
#source $config_file
#
# Obtener la muestra actual y crear una hoja de muestra
current_sample_info=$(sed -n $(( SLURM_ARRAY_TASK_ID ))p $BAM_list_file) # Obtiene fila SLURM_ARRAY_TASK_ID del fichero BAM_list_file
current_sample_id=$(echo $current_sample_info | cut -f 1 -d',') # Nos quedamos con la primera columna, es decir, el ID de la muestra
current_sample=$(echo $current_sample_info | cut -f 2 -d',') # Nos quedamos con la segunda columna, es decir, el la ruta completa de la muestra
#
# add sample ID <-> slurm log ID to mapping file
printf "\n$current_sample_id\t${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}" >> $mapping_file # De cara a revisiones, guardamos en mapping_file el ID de la muestra junto con su job ID correspondiente
#
## Codigo para ERVcaller
# Declaramos las rutas
#
output_dir=$root_output_dir'/'$current_sample_id'/' # Directorio de salida de ERV caller (cada muestra va a un directorio propio)
#
rutaERVcaller="/home/lgonzalvo/TFM/ERVcaller/ERVcaller_v1.4_masterbio.pl"
rutaReferences="/home/lgonzalvo/TFM/ERVcaller/References/"
rutaBaseDatos="/home/lgonzalvo/TFM/ERVcaller/Database/ERV_library.fa"
rutaCarpeta="/home/lgonzalvo/TFM/csvs_examples/trio/"
rutaSalida="/home/lgonzalvo/TFM/results_ERVlibrary/"
rutaFichero=""
## Genoma de referencia por defecto
genomaReferencia=hs37d5/hs37d5.fa
# genomaReferencia="hg19.fa"
#
# Obtenemos el nombre de la muestra
arrIN=(${current_sample//'/'/ })
num=${#arrIN[@]}
let c=$num-1
# Obtenemos la ruta de la muestra
longNom=${#arrIN[$c]}
longLine=${#current_sample}
let longFinal=$longLIne-$longNom
rutaCarpeta=${current_sample:0:${longFinal}}
#
fichero=${arrIN[$c]}
arrDot=(${current_sample//'.'/ })
# Obtenemos el formato
formato=.${arrDot[-1]}
long_formato=${#formato}
let len=${#fichero}-$long_formato
# Obtenemos el nombre de la muestra
nomFich=${fichero:0:${len}}
#
if [ ! -d $output_dir ];
then
	mkdir $output_dir
fi
#
perl $rutaERVcaller -i $nomFich -f $formato -H $rutaReferences$genomaReferencia -T $rutaBaseDatos -I $rutaCarpeta -O $output_dir -r $read_length -t $SLURM_CPUS_PER_TASK -S 20 -BWA_MEM

rm $job_logs_dir/*.out
