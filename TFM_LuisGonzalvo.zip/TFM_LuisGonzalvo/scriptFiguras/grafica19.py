#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 15 11:55:47 2021

@author: luis
"""
import sys
import os
from pylab import *
import matplotlib.pyplot as plot
import numpy as np
import seaborn as sb


def obtenerLongRetrovirus(listaRetrovirus, fichLong):
    dic = {}

    
    fich = open(fichLong, "r")
    
    for linea in fich:
        campos = linea.split("\t")
        
        if campos[0] != "#" and campos[0] in listaRetrovirus:
            dic[campos[0]] = campos[1].strip("\n")
            
    return dic

def obtenerListaRetrovirus(listaFich):
    
    
    listaRetrovirus = []
    
    for nom_fich in listaFich:
        fich = open(nom_fich, "r")
        
        for linea in fich:
            if linea[0] != "#":
                campos = linea.split("\t")
                retrovirus = campos[1]
                retrovirus = retrovirus[3:]

                
                if retrovirus not in listaRetrovirus:
                    listaRetrovirus.append(retrovirus)
                    
        fich.close
    
    return listaRetrovirus


def obtenerFicheros(muestrasNoRelacionadas):
    
    listaMuestras = []
    idMuestras = []
    
    fich = open(muestrasNoRelacionadas, "r")
    
    for linea in fich:
        linea = linea.strip("\n")
        cad = "/home/luis/Bioinformatica/TFM/Presentacion/datos_csvs/graficas/scriptGenerarGraficas/csvs_gtf/cat_" + linea + ".sorted.dedup.gtf"
        listaMuestras.append(cad)
        idMuestras.append(linea)
        
    fich.close()
        
    return listaMuestras, idMuestras


def obtenerDicHPO(fichGenesHPO_description):
    
    fich = open(fichGenesHPO_description, "r")
    dicHPO = {}
    for linea in fich:
        linea = linea.strip("\n")
        
        campos = linea.split("\t")
        
        dicHPO[campos[1]] = campos[0]
        
    
    fich.close()
    return dicHPO

def obtenerGenesHPO(idHPO, fichGenesHPO):
    
    fich = open(fichGenesHPO, "r")
    listaGenes = []
    for linea in fich:
        linea = linea.strip("\n")
        
        campos = linea.split(",")

        hpo_fich = campos[0]
        hpo_fich = hpo_fich[1:-1]
        
        gen = campos[2]

        gen = gen[1:-1]
        
        
        if hpo_fich == idHPO:
            listaGenes.append(gen)
            
            
    fich.close()
    
    return listaGenes

def resultadosMuestra(muestra, listaGenes, listaAlelos, dicLongRetrovirus, listaRetrovirus):
    
    fich = open(muestra, "r")
    alelosDetectados = []
    consultas = []
    retrovirus = []
    for linea in fich:
        linea = linea.strip("\n")
        if linea[0] != "#":

            
            
            campos = linea.split("\t")
            
            idRetro = campos[1]
            idRetro = idRetro[3:]
            
            chrom = campos[0]
            
            
            posIn = int(campos[3])
            if campos[4] != "NULL":
                posFin = int(campos[4])
            else:
                posFin = int(campos[3])
            gen = campos[8]
            gen = gen [6:-1]
            
            # cad = chrom + "_" +idRetro + "_" + posIn + "_" + posFin
            
            if gen in listaGenes:
                
                
                for l in listaAlelos:
                    
                    
                    camposL = l.split("_")
                    chromAlelo = camposL[0]
                    posAlelo = int(camposL[1])
                    retroAlelo = camposL[2]

                    if retroAlelo in listaRetrovirus:
                        longRet = int(dicLongRetrovirus[retroAlelo])
                        
                        posInAlelo = posAlelo - (longRet//2)
                        posFinAlelo = posAlelo + (longRet//2)
    
                        if chromAlelo == chrom:
                            
                            if posInAlelo <= posIn and posFinAlelo >= posFin:
            
                                alelosDetectados.append(l)
                                consultas.append(linea)
                                if retroAlelo not in retrovirus:
                                    retrovirus.append(retroAlelo)
                        
    
    
    
    fich.close()
            
    return alelosDetectados, consultas, retrovirus


def obtenerListaAlelos(fich_matrix):
    
    fich = open(fich_matrix, "r")
    listaAlelos = []
    for linea in fich:
        if linea[0] != "#":
            campos = linea.split("\t")
            
            listaAlelos.append(campos[0])
    

    fich.close()
    return listaAlelos

def plot_grafica(listaRetrovirus, consultas, hpo, dicLongRetrovirus, carpeta_out):
    
    for retrovirus in listaRetrovirus:

        lista = []
        contNoAparece = 0
        legend = []
        listaIn = []
        listaFin = []
        datos = []

        for c in consultas:

            campos = c.split("\t")

           
            r_id = campos[1]
            r_id = r_id[3:]


            if r_id == retrovirus:

                
                info = campos[9]
                camposInfo = info.split(",")

                
                if camposInfo[1] != "NULL" and camposInfo[2] != "NULL":
                    
                    listaIn.append(int(camposInfo[1]))
                    listaFin.append(int(camposInfo[2]))
                


        nucleotidos = []
            
        long = int(dicLongRetrovirus[retrovirus])

            
        for x in range(long):
                nucleotidos.append(0)
                
            
        total = []
            # print("longitud", long)

        for l in range(len(listaIn)):
                
            if int(listaFin[l]) > long:
                listaFin[l] = long
                
            for i in range(int(listaIn[l])-1, int(listaFin[l])-1):
                nucleotidos[i] += 1


        cont = 0
        for n in nucleotidos:
            if n != 0:
                
                cont += 1
            
            lista.append(n)
        
        
        if cont >= 1:
            
            
            long = len(lista)
            bins = np.arange(0, long)

                
            plot.plot(bins, nucleotidos)
            
                
            plot.ylabel('Frecuencia')
            plot.xlabel('Nucleotidos')
            m = len(lista) - contNoAparece
            titulo = hpo + ":" +retrovirus
            plot.title(titulo)
            
            # plot.show()
            
            jpg = carpeta_out + hpo + "_" + retrovirus + ".jpg"
            plot.savefig(jpg)
            
            plot.show()
            

        

def main():
    
    fichGenesHPO_description = "gProfiler_hpo_heredados_description.txt"
    fichGenesHPO = "gProfiler_hpo_heredados.csv"
    
    carpeta_out = "/home/luis/Bioinformatica/TFM/Presentacion/datos_csvs/graficas/scriptGenerarGraficas/graficas_HPO/"

    
    carpeta = "/home/luis/Bioinformatica/TFM/Presentacion/datos_csvs/muestrasNoRelacionadas/MuestrasNoRelacionadas_completa"
    fichMatrix = "/home/luis/Bioinformatica/TFM/Presentacion/datos_csvs/matrixAlelosFamilias.txt"
    fich_long = "/home/luis/Bioinformatica/TFM/Presentacion/datos_csvs/fich_long.txt"


    # listaMuestras = ["/home/luis/Bioinformatica/TFM/Presentacion/datos_csvs/graficas/scriptGenerarGraficas/csvs_gtf/cat_AC5742.sorted.dedup.gtf", "/home/luis/Bioinformatica/TFM/Presentacion/datos_csvs/graficas/scriptGenerarGraficas/csvs_gtf/cat_AC5779.sorted.dedup.gtf"]
    listaMuestras, idMuestas = obtenerFicheros(carpeta)
    listaAlelos = obtenerListaAlelos(fichMatrix)
    listaRetrovirus = obtenerListaRetrovirus(listaMuestras)
    dicLongRetrovirus = obtenerLongRetrovirus(listaRetrovirus, fich_long)
    
    
    dicHPO = obtenerDicHPO(fichGenesHPO_description)
    
    consultas = []
    for hpo in dicHPO:
        listaAlelosDetectados_final = []
        print(dicHPO[hpo])
        retrovirus = []
        listaGenes = obtenerGenesHPO(dicHPO[hpo], fichGenesHPO)
        consultas = []
        
        for muestra in listaMuestras:
                
            
            listaAlelosDetectados, consultas, retroAlelo = resultadosMuestra(muestra, listaGenes, listaAlelos, dicLongRetrovirus, listaRetrovirus)

            
            for alelo in listaAlelosDetectados:
                campos = alelo.split("_")
                if campos[2] not in retrovirus:
                    retrovirus.append(campos[2])
                if alelo not in listaAlelosDetectados_final:
                    
                    listaAlelosDetectados_final.append(alelo)
            
        plot_grafica(retroAlelo, consultas, hpo, dicLongRetrovirus, carpeta_out)
        
        nomFich_out = carpeta_out + hpo + ".txt"
        
        fich_out = open(nomFich_out, "w")
        fich_out.close()
        
        fich_out = open(nomFich_out, "a")
        
        cad = "# En " + hpo + " se han encontrado " + str(len(listaAlelosDetectados_final)) + "\n" 
        for l in listaAlelosDetectados_final:
            cad += l  + "\n"
        
        fich_out.write(cad)
        fich_out.close()
        
        plot_grafica(retroAlelo, consultas, hpo, dicLongRetrovirus, carpeta_out)


    
if __name__ == '__main__':

    main()