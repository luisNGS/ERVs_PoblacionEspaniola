#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 10 09:23:41 2021

@author: luis
"""

from bokeh.io import output_file, show
from bokeh.models import ColumnDataSource, FactorRange
from bokeh.plotting import figure
from bokeh.transform import factor_cmap

output_file("./grafica6.html")

retrovirus = ['ERV_library']
options = ['BAM crudo/Genoma completo', 'BAM filtrado/Genoma completo','BAM crudo/Exoma', 'BAM filtrado/Exoma']

data = {'Counts' : retrovirus,
        'BAM crudo/Genoma completo'   : [2739],
        'BAM filtrado/Genoma completo'   : [74],
        'BAM crudo/Exoma'   : [3],
        'BAM filtrado/Exoma'   : [0]}

palette = ["#718dbf", "#FFFF00", "#f80000", "#c9d9d3"]


x = [ (retr, option) for retr in retrovirus for option in options ]
counts = sum(zip(data['BAM crudo/Genoma completo'], data['BAM filtrado/Genoma completo'], data['BAM crudo/Exoma'], data['BAM filtrado/Exoma']), ()) # like an hstack

source = ColumnDataSource(data=dict(x=x, counts=counts))

p = figure(x_range=FactorRange(*x), plot_height=350, title="Conteo TEs",
           toolbar_location=None, tools="")

p.vbar(x='x', top='counts', width=0.9, source=source, line_color="white",
       fill_color=factor_cmap('x', palette=palette, factors=options, start=1, end=2))

p.y_range.start = 0
p.x_range.range_padding = 0.1
p.xaxis.major_label_orientation = 1
p.xgrid.grid_line_color = None

show(p)
