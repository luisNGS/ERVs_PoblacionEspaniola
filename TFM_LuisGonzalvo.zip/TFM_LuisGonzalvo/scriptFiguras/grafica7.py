#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 25 10:37:23 2021

@author: luis
"""
from math import pi

import pandas as pd

from bokeh.io import show
from bokeh.models import BasicTicker, ColorBar, LinearColorMapper, PrintfTickFormatter
from bokeh.plotting import figure
from bokeh.sampledata.unemployment1948 import data


nomFich = "/home/luis/Bioinformatica/TFM/results/pruebasCSVS/ComparacionHERVK/nav_genome_example.sorted.dedup.cbra.txt"

sortedSites = "./sortedSites"

fich = open(sortedSites, "r")

valorHERVK = 0.9
dicAlelos = {}

for linea in fich:
    linea = linea.strip("\n")
    
    dicAlelos[linea] = ""

fich.close()


fich = open(nomFich, "r")

for linea in fich:
    if linea[0] != "#":
        linea = linea.strip("\n")
        campos = linea.split("\t")
        alelo = campos[0]
        muestra1 = campos[1]
        muestra2 = campos[2]
        
        cad = ""
        
        if int(muestra1) >= 1:
            cad += "1,"
        else:
            cad += "0,"
            
        if float(muestra2) >= valorHERVK:
            cad += "1"
        else:
            cad += "0"
            
        
        if cad == "1,0":
            print("----------------")
            print(muestra1, muestra2, alelo)
    
        
        dicAlelos[alelo] = cad
    
fich.close()

listaAlelos = []
datosMuestra1 = []
datosMuestra2 = []

for key in dicAlelos:
    print(key, dicAlelos[key])
    listaAlelos.append(key)
    
    cad = dicAlelos[key]
    
    campos = cad.split(",")
    
    datosMuestra1.append(int(campos[0]))
    datosMuestra2.append(int(campos[1]))

df = pd.DataFrame()


df['alelos'] = listaAlelos
df['ERVCaller'] = datosMuestra1
df['polymorphicHERV'] = datosMuestra2


print(df)
df['alelos'] = df['alelos'].astype(str)
df = df.set_index('alelos')

print(df)
data.columns.name = 'Muestras'
alelos = list(df.index)
muestras = list(df.columns)



# reshape to 1D array or rates with a month and year for each row.
df1 = pd.DataFrame(df.stack(), columns=['rate']).reset_index()

# this is the colormap from the original NYTimes plot
colors = ["#75968f", "#550b1d"]
mapper = LinearColorMapper(palette=colors, low=0, high=1)
TOOLS = "hover,save,pan,box_zoom,reset,wheel_zoom"

p = figure(title="Tool comparison",
            x_range=alelos, y_range=list(reversed(muestras)),
            x_axis_location="above", plot_width=900, plot_height=250,
            tools=TOOLS, toolbar_location='below',
            tooltips=[('Alelo', '@alelos'), ('rate', '@rate')])

p.grid.grid_line_color = None
p.axis.axis_line_color = None
p.axis.major_tick_line_color = None
p.axis.major_label_text_font_size = "7px"
p.axis.major_label_standoff = 0
p.xaxis.major_label_orientation = pi / 3

p.rect(x="alelos", y="level_1", width=1, height=1,
        source=df1,
        fill_color={'field': 'rate', 'transform': mapper},
        line_color=None)

color_bar = ColorBar(color_mapper=mapper, major_label_text_font_size="7px",
                      ticker=BasicTicker(desired_num_ticks=len(colors)),
                      formatter=PrintfTickFormatter(format="%s"),
                      label_standoff=6, border_line_color=None)
p.add_layout(color_bar, 'right')

show(p)      # show the plot