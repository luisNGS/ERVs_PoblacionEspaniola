#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jul 19 15:53:29 2021

@author: luis
"""

import os
import matplotlib.pyplot as plt
import numpy as np
import math
from math import pi
import pandas as pd
from bokeh.io import show
from bokeh.models import BasicTicker, ColorBar, LinearColorMapper, PrintfTickFormatter
from bokeh.plotting import figure
from bokeh.sampledata.unemployment1948 import data



def obtenerListaRetrovirus(ficheros):
    
    listaRetrovirus = []
    
    if type(ficheros) == list:
        
        
        for f in ficheros:
            fichOpen = open(f, "r")
            
            for linea in fichOpen:
                if linea[0] != "#":
                    campos = linea.split("\t")
                    #print(campos)
                    retroVirus = campos[1]
                    retroVirus = retroVirus[3:]
                    
                    
                    if retroVirus not in listaRetrovirus:
                    
                        listaRetrovirus.append(retroVirus)
                        
            fichOpen.close()
            
    else:
        fichOpen = open(ficheros, "r")
            
        for linea in fichOpen:
            if linea[0] != "#":
                campos = linea.split("\t")
                retroVirus = campos[1]
                retroVirus = retroVirus[3:]
                    
                if retroVirus not in listaRetrovirus:
                    listaRetrovirus.append(retroVirus)
                        
        fichOpen.close()
            
    return listaRetrovirus 


def obtenerFicheros(muestrasNoRelacionadas):
    
    listaMuestras = []
    idMuestras = []
    
    fich = open(muestrasNoRelacionadas, "r")
    
    for linea in fich:
        linea = linea.strip("\n")
        cad = "cat_" + linea + ".sorted.dedup.gtf"
        listaMuestras.append(cad)
        idMuestras.append(linea)
        
    fich.close()
        
    return listaMuestras, idMuestras

def obtenerLongRetrovirus(fichLong):
    dic = {}

    
    fich = open(fichLong, "r")
    
    for linea in fich:
        campos = linea.split("\t")
        
        if campos[0] != "#":
            dic[campos[0]] = campos[1].strip("\n")
            
    return dic

def mapaColor(arrayBidimensional):

    fig, ax = plt.subplots()
    #x = np.random.random((16, 16))
   
    matriz = [] 
    for linea in arrayBidimensional:
        lista = []
        for campo in linea:
            
            
            if campo != 0:
                #valor = math.log2(campo)
                valor = math.log10(campo)
                
            
            lista.append(valor)
           
        matriz.append(lista)

    ax.imshow(matriz)
    
    plt.ylabel('Retrovirus')
    plt.xlabel('Regiones')
    
    titulo = "Mapa de calor"
    plt.title(titulo)

    
    jpg = "./mapaCalorRetrovirus_regiones.jpg"
    plt.savefig(jpg)
    plt.show()


def obtenerRegionesCromosomas(fichero_regiones, n_regiones = 300):
    
    
    cromosomas = ["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","X","Y"]
    cromosomas_mod = []
    listaRegiones = []
    for c in cromosomas:
        crom = '"chr' + c + '"'
        cromosomas_mod.append(crom)
        
        
    for i in cromosomas_mod:
        fich = open(fichero_regiones, "r")
        
        for linea in fich:
            if linea[0] != "#":
                campos = linea.split(" ")
                
    
                    
        
                if campos[0] == i:
                    listaRegiones.append(campos)
                    
        fich.close()
                        

    
    regiones = (len(listaRegiones) // n_regiones) + 1
    print(len(listaRegiones))
    print(regiones)
    
    partes = []
    cont = 0
    for i in listaRegiones:
        
        chrom = i[0]
        chrom = chrom[1:-1]
        # print(i)
        # print(cont)
        if cont == 0:
            
            # print(chrom, i[1])
            cad = chrom + ":" + i[1] + "-"
            
            
        cont += 1
        
        if cont == regiones:

            # print(chrom, i[2])
            cad += chrom + ":" + i[2]
            partes.append(cad)
            cont = 0
        
    cad += chrom + ":" + i[2]
    partes.append(cad)
    # print(chrom, i[2])
    
    
    # print(partes)
    
    return partes

def filtrarCromosomas(chrom):

    if chrom != "X" and chrom != "Y":
        chrom = int(chrom)
        
    if chrom == "X":
        chrom = 23
        
    if chrom == "Y":
        chrom = 24
    
    return chrom


def generarGrafica(cad):
    
    df = pd.DataFrame()
    df2 = pd.DataFrame()
    
    print(cad)
    
    lineas = cad.strip("\n")
    lineas = lineas.split("\n")

    
    regiones = lineas[0]
    regiones = regiones.split("\t")
    regiones = regiones[1:-1]
    

    
    ## Obtener los retrovirus
    retrovirus = []
    for i in range(1, len(lineas)):
        print(lineas[i])
        
        campos = lineas[i].split("\t")
        
        r = "id_" + str(campos[0])
        retrovirus.append(r)
        
        
    
    ## Obtener las regiones
    
    df["retrovirus"] = retrovirus 
    
    
    
    dicRegionesLista = {}
    
    for r in regiones:
        dicRegionesLista[r] = []
    
    for i in range(len(regiones)):
        c = 0
        for x in range(1,len(retrovirus)+1):

            campos = lineas[x].split("\t")
            
            #print(regiones[i], campos[i])
         
            dicRegionesLista[regiones[i]].append(campos[i+1])
            
 

            c += 1


    for region in dicRegionesLista:
        df[region] = dicRegionesLista[region]



    
    df['retrovirus'] = df['retrovirus'].astype(str)

    df = df.set_index('retrovirus')

    
    data.columns.name = 'Retrovirus'
    Retrovirus = list(df.index)
    Regiones = list(df.columns)
    

    df_reset = pd.DataFrame(df.stack(), columns=['rate']).reset_index()


    colors = ["#75968f", "#a5bab7", "#c9d9d3", "#e2e2e2", "#dfccce", "#ddb7b1", "#cc7878", "#933b41", "#550b1d", "#550b1d"]
    mapper = LinearColorMapper(palette=colors, low=float(df_reset.rate.min()), high=float(df_reset.rate.max()))
    print("mapper", mapper)
    TOOLS = "hover,save,pan,box_zoom,reset,wheel_zoom"
    
    p = figure(title="Tool comparison",
                x_range=Retrovirus, y_range=list(reversed(Regiones)),
                x_axis_location="above", plot_width=900, plot_height=2000,
                tools=TOOLS, toolbar_location='below',
                tooltips=[('date', '@Regiones @Retrovirus'), ('rate', '@rate')])
    
    p.grid.grid_line_color = None
    p.axis.axis_line_color = None
    p.axis.major_tick_line_color = None
    p.axis.major_label_text_font_size = "7px"
    p.axis.major_label_standoff = 0
    p.xaxis.major_label_orientation = pi / 3
    

    print(df_reset['rate'])
    
    p.rect(x="retrovirus", y="level_1", width=1, height=1,
            source=df_reset,
            fill_color={'field': 'rate', 'transform': mapper},
            line_color=None)
    
    color_bar = ColorBar(color_mapper=mapper, major_label_text_font_size="7px",
                          ticker=BasicTicker(desired_num_ticks=len(colors)),
                          formatter=PrintfTickFormatter(format="%s"),
                          label_standoff=6, border_line_color=None)
    p.add_layout(color_bar, 'right')
    
    show(p)      # show the plot
    # print(df2)
    
def main():
    
    carpeta = "./muestrasNoRelacionadas/MuestrasNoRelacionadas_completa"
    fichMatrix = "./matrixAlelosFamilias.txt"
    fich_long = "./fich_long.txt"
    
    
    listaMuestras, idMuestas = obtenerFicheros(carpeta)
    dicLong = obtenerLongRetrovirus(fich_long)
    listaRetrovirus = obtenerListaRetrovirus(listaMuestras)
    
    
    listaGenes = []
    

    
    
    cromosomas = ["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","X","Y"]   
    dicRegiones = {}
    
    fich_regiones = "./regionesCromosomas.txt"
    
    cromosomas = obtenerRegionesCromosomas(fich_regiones)
    
    
    for r in cromosomas:
        dicRegiones[r] = ""
    
    for c in cromosomas:
        # print("-----------------------------")
        # print("Cromosoma", c)
        # print()
        
        
        
        
        dicRetrovirus = {}
        
        for r in listaRetrovirus:
        
            dicRetrovirus[r] = 0

        for fichero in listaMuestras:
            
            # fichero = "cat_" + fichero + ".sorted.dedup.gtf"
            # print(fichero)
            fich = open(fichero, "r")
            
            listaAux = []
            
            
            for linea in fich:
                if linea[0] != "#":
                    linea = linea.strip("\n")
                    campos = linea.split("\t")
                    chrom = campos[0]
                    retroVirus = campos[1]
                    retroVirus = retroVirus[3:]
                    genes = campos[8]
                    
                    
                    

                    posDato = int(campos[3])
                    
                    # print(linea)
                    
                    
                    # if c == chrom:
                        # dicRetrovirus[retroVirus] += 1 ## Cuando es con cromosomas
                        
                                           ## Desde aqui con regiones

                    chrom = filtrarCromosomas(chrom)
                    

                    
                    camposRegiones = c.split("-")
                    desde = camposRegiones[0].split(":")
                    chromIn = desde[0]
                    chromIn = chromIn[3:]
                    chromIn = filtrarCromosomas(chromIn)
                    posIn = int(desde[1])
                    
                    hasta = camposRegiones[1].split(":")
                    chromFin = hasta[0]
                    chromFin = chromFin[3:]
                    chromFin = filtrarCromosomas(chromFin)
                    posFin = int(hasta[1])
                    
                    if chromIn <= chrom and chromFin >= chrom and posIn <= posDato and posFin >= posDato:
                        dicRetrovirus[retroVirus] += 1


            fich.close()
            
        cad = ""
        for key in dicRetrovirus:
            # print(key, dicRetrovirus[key])
            cad += key + ":" + str(dicRetrovirus[key]) + ","
            
        cad = cad[:-1]


        dicRegiones[c] = cad
        #print(dicRegiones[c])
        
    matriz = []

    
    for i in range(len(listaRetrovirus)):
        lista = []
    
    
        for key in dicRegiones:
            campos = dicRegiones[key].split(",")

            
            valor = campos[i].split(":")
    
            valor = int(valor[1])
            # print(i)
            
            # if valor != 0:
            #     valor = math.log2(valor)
                
            lista.append(valor)
        
        
        if sum(lista) >= 1:
            
            matriz.append(lista)
        
    
    
    
    
    nomFich_out  = "mapaCalor_matrix_regiones.txt"
    fich_out = open(nomFich_out, "w")
    fich_out.close()
    
    fich_out = open(nomFich_out, "a")
    cad = "# \t"
    
    for key in dicRegiones:
        cad += key + "\t"
        
    cad += "\n"
    
    for i in range(len(matriz)):
        cad += listaRetrovirus[i] + "\t"

        for valor in matriz[i]:
            cad += str(valor) + "\t"
            
        cad += "\n"
        
    fich_out.write(cad)

    generarGrafica(cad)
    

    
    
if __name__ == '__main__':

    main()

    
    
    
    
    
    