#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 25 12:43:05 2021

@author: luis
"""

import numpy as np
import scipy.special

from bokeh.layouts import gridplot
from bokeh.plotting import figure, output_file, show

import matplotlib.pyplot as plot
import seaborn as sb


def grafico(measured, bins):

    rangos = range(min(measured), max(measured) + 100)
    
    rangos = []
    
    x = min(measured)
    while x <= max(measured):
        rangos.append(x)
        x += bins
    rangos.append(x)
    
    frecuencias, bordes = np.histogram(measured, bins=rangos)
    
    
    # creamos la figura
    histograma = figure(title='Número de muestras en función del número de alelos',
                        x_axis_label='# alelos',
                        y_axis_label='# muestras')
    
    # añadimos las subdiviones al eje X
    histograma.xaxis.ticker = bordes
    
    # añadimos los rectángulos que representan las barras del histograma
    histograma.quad(bottom=0, top=frecuencias,
                    left=bordes[:-1], right=bordes[1:],
                    fill_color='#F2AB6D', line_color='black')
    
    
    histograma.xaxis.major_label_orientation = 1.55
    
    # mostramos el histograma
    show(histograma)
    
    
def main():

        
    
    fichMatrix = "/home/luis/Bioinformatica/TFM/Presentacion/datos_csvs/matrixLoci_union.txt"
    
    fich = open(fichMatrix, "r")
    cont = 0
    
    dic = {}
    x = 0
    y = 0
    lines = []
    rows = []
    cont = 0
    for linea in fich:
        
        
        if linea[0] != "#":
        
            
            linea = linea.strip("\n")
            
            columnas = linea.split("\t")
            columnas = columnas[1:-1]
    
            rows = []
            for c in columnas:
    
                rows.append(c)
                
            
            
            lines.append(rows)
            
        else:
        
            linea = linea.strip("\n")
            campos = linea.split("\t")
            
            campos = campos[1:-1]

    
    fich.close()

    
    ## Vamos a hacer conteo para cada muestra
    conteoEnMuestras = []
    
    for i in range(len(lines[0])):
        conteo = 0
        for x in range(len(lines)):
            if i != 55:
                valor = int(lines[x][i])
                
                if valor == 1:
                    conteo += 1
                

        conteoEnMuestras.append(conteo)
        
        
    conteoEnMuestras = sorted(conteoEnMuestras)
    conteoEnMuestras = conteoEnMuestras[1:]
            
    
    ## Vamos a hacer conteo para cada alelo
    conteoEnAlelo = []
    conteo = 0
    for i in range(len(lines)):
        conteo = 0
        for x in range(len(lines[0])):
            if i != 55:
                valor = int(lines[i][x])
                
                if valor == 1:
                    conteo += 1
            
        conteoEnAlelo.append(conteo)
        
    conteoEnAlelo = sorted(conteoEnAlelo)

    
    grafico(conteoEnMuestras, 40)
    

if __name__ == '__main__':
    
    main()
    


