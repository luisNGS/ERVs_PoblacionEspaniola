library("IdeoViz")
ideo_hg19 <- getIdeo("hg19")

dataTodosAlelos <- read.table(file = "./scripts/Generacion_matrices_alelos/matrizAlelos.txt", header = TRUE, sep = "\t") 
dataAlelosFamilias <- read.table(file = "./scripts/Generacion_matrices_alelos/matrizAlelosFamilias.txt", header = TRUE, sep = "\t")

todosAlelos <- dataTodosAlelos[,1]
alelos <- dataAlelosFamilias[,1]


chr_todos = vector()
pos_todos = numeric()
retrovirus_todos = vector()

for (i in 1:length(todosAlelos)) {
  tmp = todosAlelos[i]
  tmp <- unlist(strsplit(as.character(todosAlelos[i]), "[_]"))
  crom = paste0("chr",tmp[1])
  chr_todos <- c(chr_todos, crom)
  pos_todos <- c(pos_todos, tmp[2])
  retrovirus_todos <- c(retrovirus_todos, tmp[3])
}

chr_todos <- as.factor(chr_todos)
pos_todos <- as.numeric(pos_todos)
retrovirus_todos <- as.factor(retrovirus_todos)

chr = vector()
pos = numeric()
retrovirus = vector()


for (i in 1:length(alelos)) {
  tmp = alelos[i]
  tmp <- unlist(strsplit(as.character(alelos[i]), "[_]"))
  crom = paste0("chr",tmp[1])
  chr <- c(chr, crom)
  pos <- c(pos, tmp[2])
  retrovirus <- c(retrovirus, tmp[3])
}

chr <- as.factor(chr)
pos <- as.numeric(pos)
retrovirus <- as.factor(retrovirus)

paletaColores = c("#800000", "#FF0000", "#F08080", "#FF4500", "#FFD700", "#BDB76B", "#808000", "#FFFF00", "#9ACD32", "#7CFC00", "#00FF00", "#90EE90", "#8FBC8F", "#20B2AA", "#2F4F4F", "#008080", "#00FFFF", "#40E0D0", "#7FFFD4", "#4682B4", "#6495ED", "#00BFFF", "#1E90FF", "#191970", "#0000FF", "#8A2BE2", "#8B008B", "#C71585", "#FF1493", "#FF69B4", "#D2691E", "#708090", "#000000")

rango <- 80000 / 2

allChroms <- c("chr1","chr2","chr3","chr4","chr5","chr6","chr7","chr8","chr9","chr10","chr11","chr12","chr13","chr14","chr15","chr16","chr17","chr18","chr19","chr20","chr21","chr22","chrX","chrY")

# chr3, rango, group = retrovirus
plotChrom<-function(chrom){
  
  grTodosAlelos <- GRanges(chr_todos, IRanges((as.integer(pos_todos) - rango), (as.integer(pos_todos)) + rango), group = as.character(retrovirus_todos))
  grAlelosFamilias <- GRanges(chr, IRanges((as.integer(pos) - rango), (as.integer(pos)) + rango), group = as.character(retrovirus))
  
  grTodosAlelos <- grTodosAlelos[which(seqnames(grTodosAlelos)%in% chrom)]
  grAlelosFamilias <- grAlelosFamilias[which(seqnames(grAlelosFamilias)%in% chrom)]

  
  chrom_bins <- getBins(chrom, ideo_hg19,
                        stepSize=5*100*1000)
  
  grList <- list(grTodosAlelos,grAlelosFamilias)

  retrovirus_id = c(grTodosAlelos$group, grAlelosFamilias$group)

  retrovirus_id <- unique(retrovirus_id)
  longRetro <- length(retrovirus_id)
  colores <- head(colors(), n = longRetro)
  #pal <- c(brewer.pal(n=8,name="Dark2"),brewer.pal(n=8,name="Pastel2"))

  
  namedCols <- paletaColores[0:longRetro]
  # namedCols <- colores
  names(namedCols) <- retrovirus_id
  plotOnIdeo(chrom=seqlevels(chrom_bins), ideoTable=ideo_hg19,values=grList,
             plotType="seg_tracks",col=namedCols,vertical=F)
  
  
  print(retrovirus_id)
   #plotOnIdeo(chrom=seqlevels(chrom_bins), 
  #           ideoTable=ideo_hg19, 
   #          values_GR=grList, value_cols=colnames(mcols(grPadre)),  
    #         plotType="seg_tracks",
     #        col=namedCols, vertical=F)
  
}

pdf("./ideograma_familias.pdf")

chroms <- c ("chr1", "chr2", "chr3", "chr4", "chr5")
plotChrom(chroms)

chroms <- c ("chr6","chr7","chr8","chr9","chr10")
plotChrom(chroms)

chroms <- c ("chr11","chr12","chr13","chr14","chr15")
plotChrom(chroms)

chroms <- c ("chr16","chr17","chr18","chr19","chr20")
plotChrom(chroms)

chroms <- c ("chr21","chr22","chrX","chrY")
plotChrom(chroms)

dev.off() 

