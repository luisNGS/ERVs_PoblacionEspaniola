# -*- coding: utf-8 -*-
"""
Created on Sun Jul 25 20:46:49 2021

@author: Luis
"""

import sys
import os
from pylab import *
import matplotlib.pyplot as plot
import numpy as np
import pandas as pd

from bokeh.io import output_file, show
from bokeh.plotting import figure



def obtenerListaRetrovirus(ficheros):
    
    listaRetrovirus = []
    
    if type(ficheros) == list:
        
        
        for f in ficheros:
            fichOpen = open(f, "r")
            
            for linea in fichOpen:
                if linea[0] != "#":
                    campos = linea.split("\t")
                    retroVirus = campos[1]
                    retroVirus = retroVirus[3:]
                    
                    
                    if retroVirus not in listaRetrovirus:
                        
                        listaRetrovirus.append(retroVirus)
                        
            fichOpen.close()
            
    else:
        fichOpen = open(ficheros, "r")
            
        for linea in fichOpen:
            if linea[0] != "#":
                campos = linea.split("\t")
                retroVirus = campos[1]
                retroVirus = retroVirus[3:]
                    
                if retroVirus not in listaRetrovirus:
                    listaRetrovirus.append(retroVirus)
                        
        fichOpen.close()
        
            
    return listaRetrovirus


def obtenerFicheros(muestrasNoRelacionadas):
    
    listaMuestras = []
    idMuestras = []
    
    fich = open(muestrasNoRelacionadas, "r")
    
    for linea in fich:
        linea = linea.strip("\n")
        cad = "/home/luis/Bioinformatica/TFM/Presentacion/datos_csvs/graficas/scriptGenerarGraficas/csvs_gtf/cat_" + linea + ".sorted.dedup.gtf"
        listaMuestras.append(cad)
        idMuestras.append(linea)
        
    fich.close()
        
    return listaMuestras, idMuestras

def obtenerListaGenes(nomFich_genes):
    
    fich = open(nomFich_genes, "r")
    
    listaGenes = []
    
    for linea in fich:
        # print(linea)
        linea = linea.strip("\n")
        gen = linea[6:]
        # print(gen)
        listaGenes.append(gen)
        
    
    fich.close()
    
    return listaGenes

def obtenerHPO(nomFich_hpo):

    dicHPO = {}
    fich = open(nomFich_hpo, "r")
    
    for linea in fich:
        if linea[0] != "#":
            linea = linea.strip("\n")
            campos = linea.split("\t")
            
            dicHPO[campos[1]] = linea
            
    fich.close()
    
    return dicHPO


def obtenerOMIM(nomFich_MIMM):

    dicOMIM = {}
    listaGenesOMIM = []
    fich = open(nomFich_MIMM, "r")
    
    for linea in fich:
        if linea[0] != "#":
            linea = linea.strip("\n")
            campos = linea.split("\t")
            #print(campos[1])
            dicOMIM[campos[1]] = linea
            
            genes = campos[1]
        
            
            genes = genes.split(",")
            
            for gen in genes:
                if gen[0:1] == " ":
                    gen = gen[1:]
                    
                    if gen not in listaGenesOMIM:
                        listaGenesOMIM.append(gen)

    fich.close()
    
    return listaGenesOMIM

def HPOyMMIM(listaGenes, dicHPO, listaGenesOMIM):
    contadorHPO = 0
    contadorOMIM = 0
    for gen in listaGenes:
        if gen in dicHPO:

            contadorHPO += 1
            
        if gen in listaGenesOMIM:
            contadorOMIM += 1
            
    return len(listaGenes), contadorHPO, contadorOMIM
    
    
def HPOyMMIM_gen(gen, dicHPO, listaGenesOMIM):

    hpo = "no"
    omim = "no"

    if gen in dicHPO:
        hpo = "si"
        
        
    if gen in listaGenesOMIM:
        omim = "si"
            
    return hpo, omim
    

    
def main():
    
    nomFich_hpo = "/home/luis/Bioinformatica/TFM/Presentacion/datos_csvs/graficas/scriptGenerarGraficas/gen_info/HPO_OMIM-IVA.txt"
    nomFich_MIMM = "/home/luis/Bioinformatica/TFM/Presentacion/datos_csvs/graficas/scriptGenerarGraficas/gen_info/geneOmim_col.txt"
    
    carpeta = "/home/luis/Bioinformatica/TFM/Presentacion/datos_csvs/muestrasNoRelacionadas/MuestrasNoRelacionadas_completa"
    fichMatrix = "/home/luis/Bioinformatica/TFM/Presentacion/datos_csvs/matrixAlelosFamilias.txt"
    fich_long = "/home/luis/Bioinformatica/TFM/Presentacion/datos_csvs/fich_long.txt"
    
    
    listaMuestras, idMuestas = obtenerFicheros(carpeta)
    # listaMuestras = ["cat_fich1.sorted.dedup.gtf", "cat_fich2.sorted.dedup.gtf"]   
    listaRetrovirus = obtenerListaRetrovirus(listaMuestras)
    
    dicRetrGenes = {}
    for retrovirus in listaRetrovirus:
        dicRetrGenes[retrovirus] = []
        
    for muestra in listaMuestras:
        fich = open(muestra, "r")
        
        for linea in fich:
            if linea[0] != "#":
                linea = linea.strip("\n")

                campos = linea.split("\t")
                retr = campos[1]
                retr = retr[3:]

                genes = campos[8]
                
                if genes != "-":
                    genes = genes[:-1]
                    
                    genes = genes.split(";")
                    
                    for gen in genes:

                        gen = gen[6:]
                        
                        if gen not in dicRetrGenes[retr]:
                            dicRetrGenes[retr].append(gen)
            
        
        
        fich.close()
        
    retrovirus = []
    
    
    dicHPO = obtenerHPO(nomFich_hpo)
    
    listaGenesOMIM = obtenerOMIM(nomFich_MIMM)
    
    
    r = []
    genesTotal = []
    genesHPO = []
    genesOMIM = []
    

    
    dicContador = {}
    
    dicContador["retrovirus"] = []
    dicContador["HPO"] = []
    dicContador["no-HPO"] = []

    retrovirus = []
    
    for key in dicRetrGenes:
        
        
        if len(dicRetrGenes[key]) >= 1:
            
            
            retrovirus.append(key)
                
            print(key)
            contadorTotal = 0
            contadorHPO = 0
            contadorOMIM = 0
            contadorHPO_OMIM = 0
            for gen in dicRetrGenes[key]:
                
                hpo, omim = HPOyMMIM_gen(gen, dicHPO, listaGenesOMIM)
                
                contadorTotal += 1
            
                r.append(key)
                genesTotal.append(gen)
                genesHPO.append(hpo)
                genesOMIM.append(omim)
                
                if hpo == "si":
                    if omim == "si":
                        contadorHPO_OMIM += 1
                    
                    else:
                        contadorHPO += 1
                        
                else:
                    if omim == "si":
                        contadorOMIM += 1
                    
                
                
                
                cad = key + "\t" + gen  + "\t" + hpo + "\t" + omim + "\n"
                
   
            dicContador["retrovirus"].append(key)
            cont = contadorHPO + contadorHPO_OMIM
            dicContador["HPO"].append(cont)
            
            contNoHPO = contadorTotal - cont
            
            dicContador["no-HPO"].append(contNoHPO)
        

    
    opciones = ["HPO", "no-HPO"]

    colors = ["#38DB96", "#3B83BD"]


    output_file("/home/luis/Bioinformatica/TFM/Presentacion/datos_csvs/graficas/scriptGenerarGraficas/graficas/graficaHPO_mod.html")


    p = figure(x_range=retrovirus, plot_height=500, title="Conteo de genes por anotación",
               toolbar_location=None, tools="hover", tooltips="$name @retrovirus: @$name")
    
    p.vbar_stack(opciones, x='retrovirus', width=0.9, color=colors, source=dicContador,
                 legend_label=opciones)
    
    p.y_range.start = 0
    p.x_range.range_padding = 0.1
    p.xgrid.grid_line_color = None
    p.axis.minor_tick_line_color = None
    p.outline_line_color = None
    p.xaxis.major_label_orientation = 1.3
    p.legend.location = "top_right"
    p.legend.orientation = "horizontal"
    
    show(p)

    
if __name__ == '__main__':
    
    main()
    
    