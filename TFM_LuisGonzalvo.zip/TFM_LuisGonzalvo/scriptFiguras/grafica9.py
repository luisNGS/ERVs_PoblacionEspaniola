#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 15 19:11:11 2021

@author: luis
"""

import sys
import os
from pylab import *
import matplotlib.pyplot as plot
import numpy as np
import seaborn as sb


def obtenerListaRetrovirus(fich_retrovirus):
    listaRetrovirus = []
    fich = open(fich_retrovirus, "r")
    for linea in fich:
        linea = linea.strip("\n")
        listaRetrovirus.append(linea)
                
            
    return listaRetrovirus

def main():
    

    carpetaMuestras = "./muestras/"
    rutaPlot = "./graficas/"
    
    listaMuestras = os.listdir(carpetaMuestras)
    fich_retrovirus = "lista_RetrovirusAlelosHeredados.txt"
    listaRetrovirus = obtenerListaRetrovirus(fich_retrovirus)    
    carpetaSalida = "./graficas/"

    
    for retrovirus in listaRetrovirus:

        
        lista = []
        contNoAparece = 0
        legend = []
        
        for muestra in listaMuestras:
            muestra = carpetaMuestras + muestra
            fich = open(muestra, "r")
            
            for linea in fich:
                campos = linea.split("\t")
                
                if campos[0] == retrovirus:
                    lista.append(campos[1])

                    
        if len(lista) >= 1:
            
            long = len(lista[0].split(","))
            bins = np.arange(0, long)
            print(len(lista))
            
            for d in lista:
                aux = []
                d = d.strip("\n")
                valores = d.split(",")
                n_valores = len(valores)
                contValores = 0

                for v in valores:
                    v = int(v)
                    aux.append(int(v))
                    if v == 0:
                        contValores += 1

                
                if contValores != n_valores:
                    
                    plot.plot(bins, aux)
                    legend.append(muestra)
                    

                    
                else:
                    contNoAparece += 1
                    print(contNoAparece)
                    print("Este no aparece ningúno")
                
            plot.ylabel('Frecuencia')
            plot.xlabel('Nucleotidos')
            m = len(lista) - contNoAparece
            print(len(lista), contNoAparece, m)
            titulo = retrovirus + ":" +str(m) + "/" + str(len(lista)-1)  + "/" +  str(len(listaMuestras)-1)
            plot.title(titulo)
            
            jpg = rutaPlot + retrovirus + ".jpg"
            plot.savefig(jpg)
            plot.show()
       
            
        
                    


if __name__ == '__main__':
    
    main()