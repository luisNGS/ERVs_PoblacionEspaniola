library("IdeoViz")
ideo_hg19 <- getIdeo("hg19")

dataPadre <- read.table(file = "./catalogo_AN7589.sorted.dedup.gtf", header = TRUE, sep = "\t") 
dataMadre <- read.table(file = "./catalogo_AN7588.sorted.dedup.gtf", header = TRUE, sep = "\t")
dataHijo <- read.table(file = "./catalogo_AN7587.sorted.dedup.gtf", header = TRUE, sep = "\t")

strandPadre <- as.character(dataPadre[,7])
strandMadre <- as.character(dataMadre[,7])
strandHijo <- as.character(dataHijo[,7])
rango <- 500000 / 2

allChroms <- c("chr1","chr2","chr3","chr4","chr5","chr6","chr7","chr8","chr9","chr10","chr11","chr12","chr13","chr14","chr15","chr16","chr17","chr18","chr19","chr20","chr21","chr22","chrX","chrY")

plotChrom<-function(chrom){
  
  grPadre <- GRanges(dataPadre[,1],IRanges((dataPadre[,4] - rango),(dataPadre[,4]) + rango), strand = strandPadre , group = as.character(dataPadre[,2]))
  grMadre <- GRanges(dataMadre[,1],IRanges((dataMadre[,4] - rango),(dataMadre[,4]) + rango), strand = strandMadre , group = as.character(dataMadre[,2]))
  grHijo <- GRanges(dataHijo[,1],IRanges((dataHijo[,4] - rango),(dataHijo[,4]) + rango), strand = strandHijo , group = as.character(dataHijo[,2]))
  
  grPadre <- grPadre[which(seqnames(grPadre)%in% chrom)]
  grMadre <- grMadre[which(seqnames(grMadre)%in% chrom)]
  grHijo <- grHijo[which(seqnames(grHijo)%in% chrom)]
  
  chrom_bins <- getBins(chrom, ideo_hg19,
                        stepSize=5*100*1000)
  
  grList <- list(grPadre, grMadre, grHijo)

  retrovirus = c(grPadre$group, grMadre$group, grHijo$group)

  retrovirus <- unique(retrovirus)
  longRetro <- length(retrovirus)
  colores <- head(colors(), n = longRetro)
  pal <- c(brewer.pal(n=8,name="Dark2"),brewer.pal(n=8,name="Pastel2"))

  
  namedCols <- pal[0:longRetro]
  names(namedCols) <- retrovirus
  plotOnIdeo(chrom=seqlevels(chrom_bins), ideoTable=ideo_hg19,values=grList,
             plotType="seg_tracks",col=namedCols,vertical=F)
  
  
  
   #plotOnIdeo(chrom=seqlevels(chrom_bins), 
  #           ideoTable=ideo_hg19, 
   #          values_GR=grList, value_cols=colnames(mcols(grPadre)),  
    #         plotType="seg_tracks",
     #        col=namedCols, vertical=F)
  
}

pdf("trio_catalogo.pdf")

chroms <- c ("chr1", "chr2", "chr3", "chr4", "chr5")
plotChrom(chroms)

chroms <- c ("chr6","chr7","chr8","chr9","chr10")
plotChrom(chroms)

chroms <- c ("chr11","chr12","chr13","chr14","chr15")
plotChrom(chroms)

chroms <- c ("chr16","chr17","chr18","chr19","chr20")
plotChrom(chroms)

chroms <- c ("chr21","chr22","chrX","chrY")
plotChrom(chroms)

dev.off() 

colores
